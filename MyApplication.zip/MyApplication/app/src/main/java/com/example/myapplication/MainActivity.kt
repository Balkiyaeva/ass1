package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    lateinit var diceImage : ImageView
   // lateinit var diceImage2 : ImageView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        diceImage = findViewById(R.id.dice_image)
      //  diceImage2 = findViewById(R.id.dice_image2)

        val rollButton: Button = findViewById(R.id.rollbutton)
        rollButton.setOnClickListener{rollDice()}

        val addbutton: Button = findViewById(R.id.button2)
        addbutton.setOnClickListener{addbutton()}




    }

    private fun setImage(number: Int){
        val drawableResource = when (number) {
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }
        diceImage.setImageResource(drawableResource)
    }


    private fun rollDice(){
       /* Toast.makeText(this, "button rolled",
            Toast.LENGTH_SHORT).show()*/
        val randomInt = (1..6).random()

        val rolledText: TextView = findViewById(R.id.rolledtext)
        //rolledText.text = "Dice Rolled :^)"
        rolledText.text = randomInt.toString()
        setImage(randomInt)

    }

    private fun addbutton(){
        val resultText: TextView = findViewById(R.id.rolledtext)

        var num = 1
        if (resultText.text == getString(R.string.resText)){
            resultText.text = "1"
        }
        else {
            num = resultText.text.toString().toInt()
            if (num < 6){
                num++
                resultText.text = num.toString()
            }
        }
        setImage(num)
    }
}